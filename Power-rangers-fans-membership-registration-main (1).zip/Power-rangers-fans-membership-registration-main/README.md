# Power-rangers-fans-membership-registration
A fans registration website were site visitors/fans and followers sign up to purchase for their fan membership registration card.
